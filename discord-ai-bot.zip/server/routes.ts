import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertBotConfigSchema, insertCommandSchema } from "@shared/schema";
import { initBot, restartBot } from "./bot";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // API Routes
  // Bot Stats
  app.get("/api/stats", async (req, res) => {
    try {
      const stats = await storage.getBotStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bot stats" });
    }
  });

  // Bot Config
  app.get("/api/config", async (req, res) => {
    try {
      const config = await storage.getBotConfig();
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bot configuration" });
    }
  });

  app.post("/api/config", async (req, res) => {
    try {
      const data = insertBotConfigSchema.parse(req.body);
      const updatedConfig = await storage.updateBotConfig(data);
      res.json(updatedConfig);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid configuration data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update bot configuration" });
      }
    }
  });

  // Commands
  app.get("/api/commands", async (req, res) => {
    try {
      const commands = await storage.getCommands();
      res.json(commands);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch commands" });
    }
  });

  app.post("/api/commands", async (req, res) => {
    try {
      const data = insertCommandSchema.parse(req.body);
      const command = await storage.createCommand(data);
      res.json(command);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid command data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create command" });
      }
    }
  });

  app.patch("/api/commands/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid command ID" });
      }

      const data = insertCommandSchema.partial().parse(req.body);
      const command = await storage.updateCommand(id, data);
      
      if (!command) {
        return res.status(404).json({ message: "Command not found" });
      }
      
      res.json(command);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid command data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to update command" });
      }
    }
  });

  app.delete("/api/commands/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid command ID" });
      }

      const success = await storage.deleteCommand(id);
      
      if (!success) {
        return res.status(404).json({ message: "Command not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete command" });
    }
  });

  // Recent Messages
  app.get("/api/messages", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
      const messages = await storage.getMessages(limit);
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch messages" });
    }
  });

  // Bot Control
  app.post("/api/bot/restart", async (req, res) => {
    try {
      await restartBot();
      res.json({ success: true, message: "Bot restarting" });
    } catch (error) {
      res.status(500).json({ message: "Failed to restart bot" });
    }
  });

  // Initialize bot
  await initBot();

  return httpServer;
}

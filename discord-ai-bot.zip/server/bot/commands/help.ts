import { Message, EmbedBuilder } from 'discord.js';
import { storage } from '../../storage';
import { logger } from '../utils/logger';

export const helpCommand = {
  name: 'help',
  description: 'Shows available commands or info about a specific command',
  isActive: true,
  
  async execute(message: Message, args: string[]) {
    try {
      const commands = await storage.getCommands();
      const config = await storage.getBotConfig();
      const prefix = config?.prefix || '!';
      
      // Check if asking for a specific command
      if (args.length > 0) {
        const commandName = args[0].toLowerCase();
        const command = commands.find(cmd => cmd.name === commandName);
        
        if (!command) {
          return message.reply(`The command \`${commandName}\` was not found.`);
        }
        
        const embed = new EmbedBuilder()
          .setColor('#7289DA')
          .setTitle(`Command: ${prefix}${command.name}`)
          .setDescription(command.description)
          .addFields(
            { name: 'Usage', value: command.usage },
            { name: 'Status', value: command.isActive ? 'Active' : 'Disabled' }
          );
        
        return message.reply({ embeds: [embed] });
      }
      
      // Show all commands
      const activeCommands = commands.filter(cmd => cmd.isActive);
      
      const embed = new EmbedBuilder()
        .setColor('#7289DA')
        .setTitle('Available Commands')
        .setDescription(`Use \`${prefix}help [command]\` for more info about a specific command.`)
        .addFields(
          activeCommands.map(cmd => {
            return {
              name: `${prefix}${cmd.name}`,
              value: cmd.description,
              inline: true
            };
          })
        );
      
      message.reply({ embeds: [embed] });
      
      // Log the interaction
      await storage.createMessage({
        userId: message.author.id,
        username: message.author.username,
        serverId: message.guild?.id || 'DM',
        serverName: message.guild?.name || 'Direct Message',
        content: `!help ${args.join(' ')}`,
        isBot: false,
        createdAt: new Date()
      });
      
    } catch (error) {
      logger.error("Error in help command:", error);
      message.reply('Sorry, I encountered an error while retrieving commands.');
    }
  }
};

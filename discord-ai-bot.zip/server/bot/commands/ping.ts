import { Message } from 'discord.js';
import { storage } from '../../storage';

export const pingCommand = {
  name: 'ping',
  description: 'Check bot latency',
  isActive: true,
  
  async execute(message: Message) {
    const sentMessage = await message.reply('Pinging...');
    
    // Calculate round-trip latency
    const roundTripLatency = sentMessage.createdTimestamp - message.createdTimestamp;
    
    // Get WebSocket latency
    const wsLatency = message.client.ws.ping;
    
    await sentMessage.edit(`Pong! 🏓\nLatency: ${roundTripLatency}ms\nAPI Latency: ${wsLatency}ms`);
    
    // Log the interaction
    await storage.createMessage({
      userId: message.author.id,
      username: message.author.username,
      serverId: message.guild?.id || 'DM',
      serverName: message.guild?.name || 'Direct Message',
      content: '!ping',
      isBot: false,
      createdAt: new Date()
    });
  }
};

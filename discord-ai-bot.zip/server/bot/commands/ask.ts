import { Message } from 'discord.js';
import { generateAIResponse } from '../utils/openai';
import { storage } from '../../storage';
import { logger } from '../utils/logger';

export const askCommand = {
  name: 'ask',
  description: 'Ask the AI a question',
  isActive: true,
  
  async execute(message: Message, args: string[]) {
    // Check if the message has content
    if (args.length === 0) {
      message.reply('Please provide a question after the !ask command.');
      return;
    }
    
    // Get the question from arguments
    const question = args.join(' ');
    
    try {
      // Show typing indicator while generating response
      message.channel.sendTyping();
      
      // Get bot configuration
      const config = await storage.getBotConfig();
      
      // Generate AI response
      const response = await generateAIResponse(question, {
        model: config?.model || 'gpt-3.5-turbo',
        maxTokens: config?.maxTokens || 500
      });
      
      // Send the response
      await message.reply(response);
      
      // Log the interaction
      await logInteraction(message, question, response);
      
      // Update API call stats
      const stats = await storage.getBotStats();
      await storage.updateBotStats({
        apiCalls: (stats?.apiCalls || 0) + 1,
        tokensUsed: (stats?.tokensUsed || 0) + estimateTokens(question + response)
      });
      
    } catch (error) {
      logger.error("Error in ask command:", error);
      message.reply('Sorry, I encountered an error while processing your request.');
    }
  }
};

// Helper function to log interactions to the database
async function logInteraction(message: Message, question: string, response: string) {
  try {
    // Log user message
    await storage.createMessage({
      userId: message.author.id,
      username: message.author.username,
      serverId: message.guild?.id || 'DM',
      serverName: message.guild?.name || 'Direct Message',
      content: `!ask ${question}`,
      isBot: false,
      createdAt: new Date()
    });
    
    // Log bot response
    await storage.createMessage({
      userId: message.client.user?.id || 'bot',
      username: message.client.user?.username || 'AI Bot',
      serverId: message.guild?.id || 'DM',
      serverName: message.guild?.name || 'Direct Message',
      content: response,
      isBot: true,
      createdAt: new Date()
    });
  } catch (error) {
    logger.error("Error logging interaction:", error);
  }
}

// Simple function to estimate token count (very rough estimation)
function estimateTokens(text: string): number {
  // Roughly 4 characters per token on average
  return Math.ceil(text.length / 4);
}

import { Client, Collection } from 'discord.js';
import { storage } from '../../storage';
import { logger } from '../utils/logger';

// Import command modules
import { askCommand } from './ask';
import { helpCommand } from './help';
import { pingCommand } from './ping';

// Interface for commands
export interface Command {
  name: string;
  description: string;
  execute: (message: any, args: string[], client: Client) => Promise<void>;
}

// Function to load commands
export async function loadCommands(client: Client) {
  try {
    client.commands = new Collection();
    
    // Register built-in commands
    const builtInCommands = [
      askCommand,
      helpCommand,
      pingCommand
    ];
    
    // Add commands to collection
    for (const command of builtInCommands) {
      client.commands.set(command.name, command);
    }
    
    // Load command status from database
    const dbCommands = await storage.getCommands();
    
    // Update command statuses based on database (enable/disable commands)
    for (const dbCommand of dbCommands) {
      const command = client.commands.get(dbCommand.name);
      
      if (command) {
        command.isActive = dbCommand.isActive;
      } else if (dbCommand.isActive) {
        // If command is in DB but not in built-in list, create stub command for future use
        logger.info(`Command ${dbCommand.name} is in database but not implemented`);
      }
    }
    
    logger.info(`Loaded ${client.commands.size} commands`);
  } catch (error) {
    logger.error("Error loading commands:", error);
  }
}

// Function to execute a command
export async function executeCommand(client: Client, message: any, commandName: string, args: string[]) {
  try {
    // Check if command exists
    const command = client.commands.get(commandName);
    
    if (!command) {
      return false;
    }
    
    // Check if command is active (from DB)
    const dbCommand = await storage.getCommand(commandName);
    if (dbCommand && !dbCommand.isActive) {
      message.reply(`The command \`${commandName}\` is currently disabled.`);
      return true;
    }
    
    // Execute command
    await command.execute(message, args, client);
    return true;
  } catch (error) {
    logger.error(`Error executing command ${commandName}:`, error);
    message.reply("There was an error executing that command.");
    return true;
  }
}

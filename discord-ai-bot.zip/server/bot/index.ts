import { Client, GatewayIntentBits, Collection } from 'discord.js';
import { storage } from '../storage';
import { loadCommands } from './commands';
import { registerEvents } from './events';
import { logger } from './utils/logger';

// Initialize client with minimal required intents
// Using only non-privileged intents for basic functionality
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
  ],
});

// Extend client to add commands collection
declare module 'discord.js' {
  interface Client {
    commands: Collection<string, any>;
  }
}

// Add commands collection to client
client.commands = new Collection();

// Bot initialization
export async function initBot() {
  try {
    // Load bot configuration
    const config = await storage.getBotConfig();
    
    if (!config) {
      logger.error("Failed to load bot configuration");
      return;
    }
    
    // Set bot status to starting
    await storage.updateBotStats({
      status: "starting"
    });
    
    // Load commands
    loadCommands(client);
    
    // Register event handlers
    registerEvents(client);
    
    // Check if Discord token is provided
    const token = process.env.DISCORD_TOKEN;
    
    if (!token) {
      logger.error("DISCORD_TOKEN environment variable is missing");
      await storage.updateBotStats({
        status: "error"
      });
      return;
    }
    
    // Login to Discord
    await client.login(token);
    
    logger.info("Discord bot initialized and logged in");
    
    // Start stats update interval
    startStatsUpdateInterval();
    
    return client;
  } catch (error) {
    logger.error("Error initializing Discord bot:", error);
    await storage.updateBotStats({
      status: "error"
    });
  }
}

// Function to restart the bot
export async function restartBot() {
  logger.info("Restarting Discord bot...");
  
  try {
    // Update bot status
    await storage.updateBotStats({
      status: "restarting"
    });
    
    // Destroy existing client
    if (client.isReady()) {
      await client.destroy();
    }
    
    // Initialize the bot again
    await initBot();
    
    return true;
  } catch (error) {
    logger.error("Error restarting Discord bot:", error);
    await storage.updateBotStats({
      status: "error"
    });
    return false;
  }
}

// Update bot stats periodically
function startStatsUpdateInterval() {
  const updateInterval = 30000; // 30 seconds
  
  setInterval(async () => {
    if (!client.isReady()) return;
    
    try {
      // Get memory usage in MB
      const memoryUsage = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
      
      // Calculate uptime in seconds
      const uptime = Math.floor(client.uptime / 1000);
      
      // Count servers
      const servers = client.guilds.cache.size;
      
      // Estimate users (sum of all guild members)
      let users = 0;
      client.guilds.cache.forEach(guild => {
        users += guild.memberCount;
      });
      
      // Update stats
      await storage.updateBotStats({
        uptime,
        servers,
        users,
        memory: memoryUsage,
        status: "online"
      });
    } catch (error) {
      logger.error("Error updating bot stats:", error);
    }
  }, updateInterval);
}

export default client;

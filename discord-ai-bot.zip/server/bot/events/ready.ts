import { Client, ActivityType } from 'discord.js';
import { storage } from '../../storage';
import { logger } from '../utils/logger';

// Handle bot ready event
export async function handleReady(client: Client) {
  try {
    logger.info(`Logged in as ${client.user?.tag}`);
    
    // Set bot status
    client.user?.setPresence({
      activities: [{ 
        name: 'your commands | !help',
        type: ActivityType.Listening
      }],
      status: 'online'
    });
    
    // Update bot stats
    const servers = client.guilds.cache.size;
    let users = 0;
    
    client.guilds.cache.forEach(guild => {
      users += guild.memberCount;
    });
    
    await storage.updateBotStats({
      status: "online",
      servers,
      users,
      uptime: 0,
      memory: Math.round(process.memoryUsage().heapUsed / 1024 / 1024)
    });
    
    logger.info(`Bot is serving ${servers} servers with approximately ${users} users`);
  } catch (error) {
    logger.error('Error in ready event handler:', error);
  }
}

import { Client } from 'discord.js';
import { handleMessageCreate } from './messageCreate';
import { handleReady } from './ready';
import { logger } from '../utils/logger';

// Register all event handlers
export function registerEvents(client: Client) {
  try {
    // Handle incoming messages
    client.on('messageCreate', (message) => handleMessageCreate(client, message));
    
    // Handle ready event
    client.once('ready', () => handleReady(client));
    
    // Handle errors
    client.on('error', (error) => {
      logger.error('Discord client error:', error);
    });
    
    // Handle disconnection
    client.on('shardDisconnect', (event, shardId) => {
      logger.warn(`Shard ${shardId} disconnected:`, event);
    });
    
    // Handle reconnection
    client.on('shardReconnecting', (shardId) => {
      logger.info(`Shard ${shardId} reconnecting...`);
    });
    
    // Handle rate limits
    client.on('rateLimited', (rateLimitInfo) => {
      logger.warn('Rate limited:', rateLimitInfo);
    });
    
    logger.info('Registered Discord event handlers');
  } catch (error) {
    logger.error('Error registering event handlers:', error);
  }
}

import { Client, Message } from 'discord.js';
import { executeCommand } from '../commands';
import { storage } from '../../storage';
import { logger } from '../utils/logger';

// Handle incoming messages
export async function handleMessageCreate(client: Client, message: Message) {
  try {
    // Ignore messages from bots
    if (message.author.bot) return;
    
    // Get bot configuration
    const config = await storage.getBotConfig();
    const prefix = config?.prefix || '!';
    
    // Check if the message starts with the command prefix
    if (!message.content.startsWith(prefix)) return;
    
    // Extract command and arguments
    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift()?.toLowerCase();
    
    if (!commandName) return;
    
    // Execute the command
    const executed = await executeCommand(client, message, commandName, args);
    
    if (!executed) {
      // Command not found
      logger.info(`Unknown command attempted: ${commandName}`);
    }
  } catch (error) {
    logger.error('Error handling message:', error);
  }
}

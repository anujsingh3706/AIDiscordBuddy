// Simple logger for the Discord bot

enum LogLevel {
  DEBUG = 0,
  INFO = 1,
  WARN = 2,
  ERROR = 3,
}

// Configure log level from environment or default to INFO
const LOG_LEVEL = process.env.LOG_LEVEL 
  ? parseLogLevel(process.env.LOG_LEVEL) 
  : LogLevel.INFO;

function parseLogLevel(level: string): LogLevel {
  switch (level.toLowerCase()) {
    case 'debug': return LogLevel.DEBUG;
    case 'info': return LogLevel.INFO;
    case 'warn': return LogLevel.WARN;
    case 'error': return LogLevel.ERROR;
    default: return LogLevel.INFO;
  }
}

export const logger = {
  debug(message: string, ...args: any[]) {
    if (LOG_LEVEL <= LogLevel.DEBUG) {
      console.log(`[DEBUG] ${new Date().toISOString()} - ${message}`, ...args);
    }
  },
  
  info(message: string, ...args: any[]) {
    if (LOG_LEVEL <= LogLevel.INFO) {
      console.log(`[INFO] ${new Date().toISOString()} - ${message}`, ...args);
    }
  },
  
  warn(message: string, ...args: any[]) {
    if (LOG_LEVEL <= LogLevel.WARN) {
      console.warn(`[WARN] ${new Date().toISOString()} - ${message}`, ...args);
    }
  },
  
  error(message: string, ...args: any[]) {
    if (LOG_LEVEL <= LogLevel.ERROR) {
      console.error(`[ERROR] ${new Date().toISOString()} - ${message}`, ...args);
    }
  }
};

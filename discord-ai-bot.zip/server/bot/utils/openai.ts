import OpenAI from "openai";
import { logger } from "./logger";

// Initialize OpenAI client
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Configuration for OpenAI requests
interface AIRequestOptions {
  model?: string;
  maxTokens?: number;
  temperature?: number;
  systemPrompt?: string;
}

// Default options for OpenAI requests
const defaultOptions: AIRequestOptions = {
  model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
  maxTokens: 500,
  temperature: 0.7,
  systemPrompt: "You are a helpful assistant in a Discord server. Provide concise, accurate responses."
};

/**
 * Generate a response from OpenAI
 */
export async function generateAIResponse(
  prompt: string,
  options: AIRequestOptions = {}
): Promise<string> {
  try {
    // Merge default options with provided options
    const mergedOptions = { ...defaultOptions, ...options };
    
    // Check if OpenAI API key is provided
    if (!process.env.OPENAI_API_KEY) {
      logger.error("OPENAI_API_KEY environment variable is missing");
      return "Sorry, the bot is not configured with an OpenAI API key.";
    }
    
    // Create messages array
    const messages = [
      {
        role: "system" as const,
        content: mergedOptions.systemPrompt || defaultOptions.systemPrompt
      },
      {
        role: "user" as const,
        content: prompt
      }
    ];
    
    // Make request to OpenAI
    const response = await openai.chat.completions.create({
      model: mergedOptions.model || defaultOptions.model,
      messages: messages,
      max_tokens: mergedOptions.maxTokens,
      temperature: mergedOptions.temperature,
    });
    
    // Extract and return the response
    const responseContent = response.choices[0]?.message?.content;
    
    if (!responseContent) {
      throw new Error("No response from OpenAI");
    }
    
    return responseContent;
  } catch (error) {
    logger.error("Error generating AI response:", error);
    
    // Provide a user-friendly error message
    if (error instanceof Error) {
      if (error.message.includes("429")) {
        return "Sorry, the AI service is currently at capacity. Please try again later.";
      } else if (error.message.includes("401")) {
        return "Sorry, there's an issue with the API authentication. Please contact the bot administrator.";
      }
    }
    
    return "Sorry, I encountered an error while generating a response.";
  }
}

import { 
  users, type User, type InsertUser,
  botConfig, type BotConfig, type InsertBotConfig,
  commands, type Command, type InsertCommand,
  messages, type Message, type InsertMessage,
  botStats, type BotStats
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Bot config operations
  getBotConfig(): Promise<BotConfig | undefined>;
  updateBotConfig(config: Partial<InsertBotConfig>): Promise<BotConfig>;
  
  // Commands operations
  getCommands(): Promise<Command[]>;
  getCommand(name: string): Promise<Command | undefined>;
  createCommand(command: InsertCommand): Promise<Command>;
  updateCommand(id: number, command: Partial<InsertCommand>): Promise<Command | undefined>;
  deleteCommand(id: number): Promise<boolean>;
  
  // Messages operations
  getMessages(limit?: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Bot stats operations
  getBotStats(): Promise<BotStats | undefined>;
  updateBotStats(stats: Partial<BotStats>): Promise<BotStats>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private botConfigs: Map<number, BotConfig>;
  private commandsList: Map<number, Command>;
  private messagesList: Message[];
  private botStatistics: Map<number, BotStats>;
  
  private userId: number;
  private configId: number;
  private commandId: number;
  private messageId: number;
  private statsId: number;

  constructor() {
    this.users = new Map();
    this.botConfigs = new Map();
    this.commandsList = new Map();
    this.messagesList = [];
    this.botStatistics = new Map();
    
    this.userId = 1;
    this.configId = 1;
    this.commandId = 1;
    this.messageId = 1;
    this.statsId = 1;
    
    // Initialize with default data
    this.initializeDefaults();
  }

  private initializeDefaults() {
    // Default bot config
    const defaultConfig: BotConfig = {
      id: this.configId,
      prefix: "!",
      model: "gpt-3.5-turbo",
      responseType: "Public Responses",
      maxTokens: 500,
      contextMemory: true,
      moderation: true
    };
    this.botConfigs.set(this.configId, defaultConfig);
    
    // Default commands
    const defaultCommands: InsertCommand[] = [
      { 
        name: "ask", 
        description: "Ask the AI a question", 
        usage: "!ask [your question]", 
        isActive: true 
      },
      { 
        name: "imagine", 
        description: "Generate an image from text", 
        usage: "!imagine [description]", 
        isActive: false 
      },
      { 
        name: "help", 
        description: "Show available commands", 
        usage: "!help [command?]", 
        isActive: true 
      },
      { 
        name: "ping", 
        description: "Check bot latency", 
        usage: "!ping", 
        isActive: true 
      }
    ];
    
    defaultCommands.forEach(cmd => {
      this.commandsList.set(this.commandId, { ...cmd, id: this.commandId });
      this.commandId++;
    });
    
    // Default bot stats
    const defaultStats: BotStats = {
      id: this.statsId,
      uptime: 0,
      servers: 0,
      users: 0,
      memory: 0,
      status: "offline",
      apiCalls: 0,
      tokensUsed: 0,
      updatedAt: new Date()
    };
    this.botStatistics.set(this.statsId, defaultStats);
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Bot config operations
  async getBotConfig(): Promise<BotConfig | undefined> {
    return this.botConfigs.get(1);
  }
  
  async updateBotConfig(config: Partial<InsertBotConfig>): Promise<BotConfig> {
    const currentConfig = await this.getBotConfig();
    const updatedConfig = { ...currentConfig, ...config };
    this.botConfigs.set(1, updatedConfig);
    return updatedConfig;
  }
  
  // Commands operations
  async getCommands(): Promise<Command[]> {
    return Array.from(this.commandsList.values());
  }
  
  async getCommand(name: string): Promise<Command | undefined> {
    return Array.from(this.commandsList.values()).find(cmd => cmd.name === name);
  }
  
  async createCommand(command: InsertCommand): Promise<Command> {
    const id = this.commandId++;
    const newCommand: Command = { ...command, id };
    this.commandsList.set(id, newCommand);
    return newCommand;
  }
  
  async updateCommand(id: number, command: Partial<InsertCommand>): Promise<Command | undefined> {
    const existingCommand = this.commandsList.get(id);
    if (!existingCommand) return undefined;
    
    const updatedCommand = { ...existingCommand, ...command };
    this.commandsList.set(id, updatedCommand);
    return updatedCommand;
  }
  
  async deleteCommand(id: number): Promise<boolean> {
    return this.commandsList.delete(id);
  }
  
  // Messages operations
  async getMessages(limit: number = 10): Promise<Message[]> {
    return this.messagesList.slice(-limit).reverse();
  }
  
  async createMessage(message: InsertMessage): Promise<Message> {
    const id = this.messageId++;
    const newMessage: Message = { ...message, id };
    this.messagesList.push(newMessage);
    
    // Keep only the last 100 messages
    if (this.messagesList.length > 100) {
      this.messagesList.shift();
    }
    
    return newMessage;
  }
  
  // Bot stats operations
  async getBotStats(): Promise<BotStats | undefined> {
    return this.botStatistics.get(1);
  }
  
  async updateBotStats(stats: Partial<BotStats>): Promise<BotStats> {
    const currentStats = await this.getBotStats();
    const updatedStats = { 
      ...currentStats, 
      ...stats,
      updatedAt: new Date()
    };
    this.botStatistics.set(1, updatedStats);
    return updatedStats;
  }
}

export const storage = new MemStorage();

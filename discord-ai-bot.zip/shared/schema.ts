import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const botConfig = pgTable("bot_config", {
  id: serial("id").primaryKey(),
  prefix: text("prefix").notNull().default("!"),
  model: text("model").notNull().default("gpt-3.5-turbo"),
  responseType: text("response_type").notNull().default("Public Responses"),
  maxTokens: integer("max_tokens").notNull().default(500),
  contextMemory: boolean("context_memory").notNull().default(true),
  moderation: boolean("moderation").notNull().default(true),
});

export const insertBotConfigSchema = createInsertSchema(botConfig).omit({
  id: true,
});

export const commands = pgTable("commands", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  usage: text("usage").notNull(),
  isActive: boolean("is_active").notNull().default(true),
});

export const insertCommandSchema = createInsertSchema(commands).omit({
  id: true,
});

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  username: text("username").notNull(),
  serverId: text("server_id").notNull(),
  serverName: text("server_name").notNull(),
  content: text("content").notNull(),
  isBot: boolean("is_bot").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertMessageSchema = createInsertSchema(messages).omit({
  id: true,
});

export const botStats = pgTable("bot_stats", {
  id: serial("id").primaryKey(),
  uptime: integer("uptime").notNull().default(0),
  servers: integer("servers").notNull().default(0),
  users: integer("users").notNull().default(0),
  memory: integer("memory").notNull().default(0),
  status: text("status").notNull().default("offline"),
  apiCalls: integer("api_calls").notNull().default(0),
  tokensUsed: integer("tokens_used").notNull().default(0),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertBotConfig = z.infer<typeof insertBotConfigSchema>;
export type BotConfig = typeof botConfig.$inferSelect;

export type InsertCommand = z.infer<typeof insertCommandSchema>;
export type Command = typeof commands.$inferSelect;

export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type Message = typeof messages.$inferSelect;

export type BotStats = typeof botStats.$inferSelect;

# Discord AI Chatbot

A Discord bot with AI-powered chat responses using Discord.js and OpenAI.

## Features

- 🤖 AI-powered responses using OpenAI's GPT models
- 💬 Command system with help, ping, and AI conversation
- ⚙️ Configuration panel for bot settings
- 📊 Dashboard with real-time stats and message history
- 🛡️ Content moderation capabilities

## Tech Stack

- **Frontend**: React, TailwindCSS, shadcn/ui components
- **Backend**: Express.js
- **Discord Integration**: Discord.js
- **AI Integration**: OpenAI API
- **State Management**: React Query

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- Discord Bot Token (from [Discord Developer Portal](https://discord.com/developers/applications))
- OpenAI API Key

### Installation

1. Clone this repository:
   ```bash
   git clone https://github.com/yourusername/discord-ai-bot.git
   cd discord-ai-bot
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file in the root directory with the following variables:
   ```
   DISCORD_TOKEN=your_discord_bot_token
   OPENAI_API_KEY=your_openai_api_key
   ```

4. Start the application:
   ```bash
   npm run dev
   ```

## Bot Commands

- `!help` - Displays all available commands
- `!ping` - Checks bot's response time
- `!ask <question>` - Ask the AI a question

## Dashboard

The bot includes a web dashboard that displays:
- Bot status (online/offline)
- Recent message history
- Usage statistics
- Configuration options

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- [Discord.js](https://discord.js.org/)
- [OpenAI](https://openai.com/)
- [shadcn/ui](https://ui.shadcn.com/)
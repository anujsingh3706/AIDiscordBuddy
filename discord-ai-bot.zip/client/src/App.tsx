import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Dashboard from "@/components/dashboard/Dashboard";
import Sidebar from "@/components/layout/Sidebar";
import MobileHeader from "@/components/layout/MobileHeader";
import { ThemeProvider } from "@/components/ui/theme-provider";
import { useState } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <div className="flex h-screen overflow-hidden bg-discord-bg text-white">
          <Sidebar />
          <MobileHeader 
            isMenuOpen={isMobileMenuOpen} 
            setIsMenuOpen={setIsMobileMenuOpen} 
          />
          <main className="flex-1 overflow-y-auto pt-0 md:pt-0 mt-16 md:mt-0">
            <Router />
          </main>
        </div>
        <Toaster />
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;

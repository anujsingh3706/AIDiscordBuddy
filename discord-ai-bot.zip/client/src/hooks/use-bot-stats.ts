import { useQuery } from "@tanstack/react-query";
import type { BotStats } from "@shared/schema";

export function useBotStats() {
  return useQuery<BotStats>({
    queryKey: ['/api/stats'],
    refetchInterval: 10000, // Refetch every 10 seconds
  });
}

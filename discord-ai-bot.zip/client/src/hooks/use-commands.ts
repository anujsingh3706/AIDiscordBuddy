import { useQuery } from "@tanstack/react-query";
import type { Command } from "@shared/schema";

export function useCommands() {
  return useQuery<Command[]>({
    queryKey: ['/api/commands'],
  });
}

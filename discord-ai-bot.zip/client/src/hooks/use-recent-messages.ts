import { useQuery } from "@tanstack/react-query";
import type { Message } from "@shared/schema";

export function useRecentMessages(limit: number = 10) {
  return useQuery<Message[]>({
    queryKey: ['/api/messages', { limit }],
    refetchInterval: 15000, // Refetch every 15 seconds
  });
}

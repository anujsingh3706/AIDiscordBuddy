import { useQuery } from "@tanstack/react-query";
import type { BotConfig } from "@shared/schema";

export function useBotConfig() {
  return useQuery<BotConfig>({
    queryKey: ['/api/config'],
  });
}

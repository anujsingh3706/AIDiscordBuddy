import { useLocation } from "wouter";

type MobileHeaderProps = {
  isMenuOpen: boolean;
  setIsMenuOpen: (isOpen: boolean) => void;
};

export default function MobileHeader({ isMenuOpen, setIsMenuOpen }: MobileHeaderProps) {
  const [location, setLocation] = useLocation();
  
  const navItems = [
    { id: "dashboard", name: "Dashboard", icon: "dashboard", path: "/" },
    { id: "settings", name: "Configuration", icon: "settings", path: "/settings" },
    { id: "commands", name: "Commands", icon: "code", path: "/commands" },
    { id: "logs", name: "Logs", icon: "article", path: "/logs" },
    { id: "help", name: "Help", icon: "help", path: "/help" },
  ];
  
  const handleNavigation = (path: string) => {
    setLocation(path);
    setIsMenuOpen(false);
  };
  
  return (
    <div className="md:hidden fixed top-0 left-0 right-0 bg-discord-dark z-10 border-b border-gray-700">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-discord-blue flex items-center justify-center mr-2">
            <span className="material-icons text-white text-sm">smart_toy</span>
          </div>
          <h1 className="text-lg font-semibold text-white">Discord AI Bot</h1>
        </div>
        <button 
          className="text-white focus:outline-none"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          <span className="material-icons">
            {isMenuOpen ? 'close' : 'menu'}
          </span>
        </button>
      </div>
      
      {/* Mobile Menu */}
      <div className={`bg-discord-dark p-4 border-b border-gray-700 ${isMenuOpen ? 'block' : 'hidden'}`}>
        <nav>
          <ul className="space-y-2">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => handleNavigation(item.path)}
                  className={`flex items-center px-4 py-2 rounded-md w-full text-left ${
                    location === item.path 
                      ? "bg-discord-blue bg-opacity-20" 
                      : "hover:bg-discord-blue hover:bg-opacity-20"
                  }`}
                >
                  <span className="material-icons mr-3">{item.icon}</span>
                  <span>{item.name}</span>
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </div>
  );
}

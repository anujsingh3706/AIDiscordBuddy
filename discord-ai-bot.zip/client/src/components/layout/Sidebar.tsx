import { useLocation } from "wouter";
import { useBotConfig } from "@/hooks/use-bot-config";

export default function Sidebar() {
  const [location, setLocation] = useLocation();
  
  const navItems = [
    { id: "dashboard", name: "Dashboard", icon: "dashboard", path: "/" },
    { id: "settings", name: "Configuration", icon: "settings", path: "/settings" },
    { id: "commands", name: "Commands", icon: "code", path: "/commands" },
    { id: "logs", name: "Logs", icon: "article", path: "/logs" },
    { id: "help", name: "Help", icon: "help", path: "/help" },
  ];
  
  const handleNavigation = (path: string) => {
    setLocation(path);
  };
  
  return (
    <aside className="hidden md:flex flex-col bg-discord-dark w-64 p-4 h-full">
      <div className="flex items-center mb-8 px-2">
        <div className="w-10 h-10 rounded-full bg-discord-blue flex items-center justify-center mr-3">
          <span className="material-icons text-white">smart_toy</span>
        </div>
        <h1 className="text-xl font-semibold text-white">Discord AI Bot</h1>
      </div>

      <nav className="flex-1">
        <ul className="space-y-2">
          {navItems.map((item) => (
            <li key={item.id}>
              <button
                onClick={() => handleNavigation(item.path)}
                className={`flex items-center px-4 py-3 rounded-md hover:bg-discord-blue hover:bg-opacity-20 transition-colors w-full text-left ${
                  location === item.path ? "bg-discord-blue bg-opacity-20" : ""
                }`}
              >
                <span className="material-icons mr-3">{item.icon}</span>
                <span>{item.name}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>

      <div className="border-t border-gray-700 pt-4 mt-4">
        <div className="flex items-center px-4 py-2">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-gray-500 flex items-center justify-center">
              <span className="material-icons text-white">person</span>
            </div>
            <div className="absolute bottom-0 right-0 w-3 h-3 bg-discord-green rounded-full border-2 border-discord-dark"></div>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-white">BotAdmin</p>
            <p className="text-xs text-discord-light">Online</p>
          </div>
        </div>
      </div>
    </aside>
  );
}

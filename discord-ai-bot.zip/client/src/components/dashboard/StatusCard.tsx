import { useBotStats } from "@/hooks/use-bot-stats";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function StatusCard() {
  const { data: stats, isLoading, refetch } = useBotStats();
  const { toast } = useToast();
  const [isRestarting, setIsRestarting] = useState(false);
  
  // Function to format uptime
  const formatUptime = (seconds: number) => {
    if (!seconds) return "Just started";
    
    const days = Math.floor(seconds / 86400);
    const hours = Math.floor((seconds % 86400) / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    let result = "";
    if (days > 0) result += `${days}d `;
    if (hours > 0) result += `${hours}h `;
    result += `${minutes}m`;
    
    return result;
  };
  
  // Function to restart the bot
  const handleRestart = async () => {
    try {
      setIsRestarting(true);
      
      await apiRequest("POST", "/api/bot/restart", {});
      
      toast({
        title: "Bot is restarting",
        description: "The bot will be back online shortly.",
      });
      
      // Poll for bot status changes
      const interval = setInterval(async () => {
        await refetch();
        
        if (stats?.status === "online") {
          clearInterval(interval);
          setIsRestarting(false);
          
          toast({
            title: "Bot is online",
            description: "The bot has successfully restarted.",
          });
        }
      }, 2000);
      
    } catch (error) {
      setIsRestarting(false);
      
      toast({
        title: "Failed to restart bot",
        description: "An error occurred while attempting to restart the bot.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="bg-discord-dark rounded-lg p-5 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">Bot Status</h3>
        <span 
          className={`px-2 py-1 rounded-full text-xs font-medium text-white ${
            stats?.status === "online" ? "bg-discord-green" : 
            stats?.status === "offline" ? "bg-discord-red" :
            stats?.status === "error" ? "bg-discord-red" :
            "bg-discord-blue"
          }`}
        >
          {stats?.status === "online" ? "Online" : 
           stats?.status === "offline" ? "Offline" :
           stats?.status === "error" ? "Error" :
           stats?.status === "starting" ? "Starting" :
           stats?.status === "restarting" ? "Restarting" :
           "Unknown"}
        </span>
      </div>
      
      <div className="space-y-4">
        <div className="flex justify-between">
          <span className="text-discord-light">Uptime</span>
          <span>{isLoading ? "Loading..." : formatUptime(stats?.uptime || 0)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-discord-light">Servers</span>
          <span>{isLoading ? "Loading..." : stats?.servers || 0}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-discord-light">Users</span>
          <span>{isLoading ? "Loading..." : stats?.users?.toLocaleString() || 0}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-discord-light">Memory Usage</span>
          <span>{isLoading ? "Loading..." : `${stats?.memory || 0} MB`}</span>
        </div>
      </div>
      
      <div className="mt-5">
        <button 
          className="w-full py-2 bg-discord-red text-white rounded-md hover:bg-opacity-90 transition-colors disabled:opacity-50"
          onClick={handleRestart}
          disabled={isRestarting || isLoading || stats?.status === "restarting" || stats?.status === "starting"}
        >
          <span className="flex items-center justify-center">
            <span className="material-icons mr-2 text-sm">power_settings_new</span>
            {isRestarting || stats?.status === "restarting" ? "Restarting..." : "Restart Bot"}
          </span>
        </button>
      </div>
    </div>
  );
}

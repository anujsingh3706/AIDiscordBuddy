import { useBotConfig } from "@/hooks/use-bot-config";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useState, useEffect } from "react";

// Form schema
const configSchema = z.object({
  prefix: z.string().min(1).max(5),
  model: z.enum(["gpt-3.5-turbo", "gpt-4o", "text-davinci-003"]),
  responseType: z.enum(["Public Responses", "DM Responses", "Ephemeral Responses"]),
  maxTokens: z.number().min(100).max(2000),
  contextMemory: z.boolean(),
  moderation: z.boolean(),
});

type ConfigFormValues = z.infer<typeof configSchema>;

export default function ConfigSection() {
  const { data: configData, isLoading } = useBotConfig();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const form = useForm<ConfigFormValues>({
    resolver: zodResolver(configSchema),
    defaultValues: {
      prefix: "!",
      model: "gpt-3.5-turbo",
      responseType: "Public Responses",
      maxTokens: 500,
      contextMemory: true,
      moderation: true,
    },
  });
  
  // Update form when data loads - using useEffect to prevent infinite loop
  useEffect(() => {
    if (configData && !form.formState.isDirty) {
      form.reset({
        prefix: configData.prefix,
        model: configData.model as any,
        responseType: configData.responseType as any,
        maxTokens: configData.maxTokens,
        contextMemory: configData.contextMemory,
        moderation: configData.moderation,
      });
    }
  }, [configData, form]);
  
  const onSubmit = async (data: ConfigFormValues) => {
    try {
      setIsSubmitting(true);
      
      await apiRequest("POST", "/api/config", data);
      
      // Invalidate config cache
      queryClient.invalidateQueries({ queryKey: ['/api/config'] });
      
      toast({
        title: "Configuration saved",
        description: "Your bot configuration has been updated.",
      });
    } catch (error) {
      toast({
        title: "Failed to save configuration",
        description: "An error occurred while saving your configuration.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleReset = () => {
    if (configData) {
      form.reset({
        prefix: configData.prefix,
        model: configData.model as any,
        responseType: configData.responseType as any,
        maxTokens: configData.maxTokens,
        contextMemory: configData.contextMemory,
        moderation: configData.moderation,
      });
      
      toast({
        title: "Form reset",
        description: "Configuration form has been reset to current values.",
      });
    }
  };
  
  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold">Quick Configuration</h3>
        <a href="#settings" className="text-discord-blue hover:underline">Advanced Settings →</a>
      </div>
      
      <div className="bg-discord-dark rounded-lg p-5 shadow-lg">
        {isLoading ? (
          <div className="h-40 flex items-center justify-center">
            <span className="text-discord-light">Loading configuration...</span>
          </div>
        ) : (
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="prefix" className="block text-sm font-medium mb-1">Command Prefix</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-discord-light">
                    <span className="material-icons text-sm">code</span>
                  </span>
                  <input 
                    type="text" 
                    id="prefix" 
                    {...form.register("prefix")}
                    className="w-full pl-9 pr-3 py-2 bg-discord-bg text-white rounded-md focus:ring-2 focus:ring-discord-blue focus:outline-none"
                  />
                </div>
                {form.formState.errors.prefix && (
                  <p className="mt-1 text-xs text-discord-red">{form.formState.errors.prefix.message}</p>
                )}
                <p className="mt-1 text-xs text-discord-light">The character(s) users type before commands</p>
              </div>
              
              <div>
                <label htmlFor="model" className="block text-sm font-medium mb-1">AI Model</label>
                <select 
                  id="model" 
                  {...form.register("model")}
                  className="w-full px-3 py-2 bg-discord-bg text-white rounded-md focus:ring-2 focus:ring-discord-blue focus:outline-none"
                >
                  <option value="gpt-3.5-turbo">gpt-3.5-turbo</option>
                  <option value="gpt-4o">gpt-4o</option>
                  <option value="text-davinci-003">text-davinci-003</option>
                </select>
                {form.formState.errors.model && (
                  <p className="mt-1 text-xs text-discord-red">{form.formState.errors.model.message}</p>
                )}
                <p className="mt-1 text-xs text-discord-light">Select which model handles generation</p>
              </div>
              
              <div>
                <label htmlFor="responseType" className="block text-sm font-medium mb-1">Response Type</label>
                <select 
                  id="responseType" 
                  {...form.register("responseType")}
                  className="w-full px-3 py-2 bg-discord-bg text-white rounded-md focus:ring-2 focus:ring-discord-blue focus:outline-none"
                >
                  <option>Public Responses</option>
                  <option>DM Responses</option>
                  <option>Ephemeral Responses</option>
                </select>
                {form.formState.errors.responseType && (
                  <p className="mt-1 text-xs text-discord-red">{form.formState.errors.responseType.message}</p>
                )}
                <p className="mt-1 text-xs text-discord-light">How the bot responds to commands</p>
              </div>
              
              <div>
                <label htmlFor="maxTokens" className="block text-sm font-medium mb-1">Max Response Length</label>
                <input 
                  type="range" 
                  id="maxTokens" 
                  min="100" 
                  max="2000" 
                  step="10"
                  {...form.register("maxTokens", { valueAsNumber: true })}
                  className="w-full accent-discord-blue bg-discord-bg"
                />
                <div className="flex justify-between mt-1 text-xs text-discord-light">
                  <span>100 tokens</span>
                  <span>{form.watch("maxTokens")} tokens</span>
                  <span>2000 tokens</span>
                </div>
              </div>
              
              <div>
                <div className="flex items-center">
                  <input 
                    type="checkbox" 
                    id="contextMemory" 
                    {...form.register("contextMemory")}
                    className="w-4 h-4 accent-discord-blue"
                  />
                  <label htmlFor="contextMemory" className="ml-2 block text-sm font-medium">Enable Conversation Memory</label>
                </div>
                {form.formState.errors.contextMemory && (
                  <p className="mt-1 text-xs text-discord-red">{form.formState.errors.contextMemory.message}</p>
                )}
                <p className="mt-1 text-xs text-discord-light">Bot remembers conversation context</p>
              </div>
              
              <div>
                <div className="flex items-center">
                  <input 
                    type="checkbox" 
                    id="moderation" 
                    {...form.register("moderation")}
                    className="w-4 h-4 accent-discord-blue"
                  />
                  <label htmlFor="moderation" className="ml-2 block text-sm font-medium">Content Moderation</label>
                </div>
                {form.formState.errors.moderation && (
                  <p className="mt-1 text-xs text-discord-red">{form.formState.errors.moderation.message}</p>
                )}
                <p className="mt-1 text-xs text-discord-light">Filter inappropriate content</p>
              </div>
            </div>
            
            <div className="mt-6 flex flex-col sm:flex-row gap-3">
              <button 
                type="submit" 
                className="flex-1 py-2 bg-discord-blue text-white rounded-md hover:bg-opacity-90 transition-colors disabled:opacity-50"
                disabled={isSubmitting}
              >
                {isSubmitting ? "Saving..." : "Save Changes"}
              </button>
              <button 
                type="button" 
                className="flex-1 py-2 bg-discord-bg text-white rounded-md hover:bg-opacity-90 transition-colors"
                onClick={handleReset}
              >
                Reset to Defaults
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}

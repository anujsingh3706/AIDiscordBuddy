import { useCommands } from "@/hooks/use-commands";
import { useBotConfig } from "@/hooks/use-bot-config";

export default function CommandsTable() {
  const { data: commands, isLoading } = useCommands();
  const { data: config } = useBotConfig();
  const prefix = config?.prefix || "!";
  
  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold">Command Quick Reference</h3>
        <a href="#commands" className="text-discord-blue hover:underline">Manage Commands →</a>
      </div>
      
      <div className="bg-discord-dark rounded-lg shadow-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-700">
            <thead className="bg-discord-bg">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-discord-light uppercase tracking-wider">Command</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-discord-light uppercase tracking-wider">Description</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-discord-light uppercase tracking-wider">Usage</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-discord-light uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            
            <tbody className="divide-y divide-gray-700">
              {isLoading ? (
                <tr>
                  <td colSpan={4} className="px-6 py-4">
                    <div className="flex items-center justify-center">
                      <span className="text-discord-light">Loading commands...</span>
                    </div>
                  </td>
                </tr>
              ) : commands && commands.length > 0 ? (
                commands.map((command) => (
                  <tr key={command.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="font-medium">{prefix}{command.name}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm">{command.description}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-sm font-mono">{command.usage}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        command.isActive 
                          ? "bg-discord-green bg-opacity-20 text-discord-green"
                          : "bg-discord-red bg-opacity-20 text-discord-red"
                      }`}>
                        {command.isActive ? "Active" : "Disabled"}
                      </span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-6 py-4">
                    <div className="flex items-center justify-center">
                      <span className="text-discord-light">No commands found</span>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

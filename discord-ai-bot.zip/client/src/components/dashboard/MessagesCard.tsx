import { useRecentMessages } from "@/hooks/use-recent-messages";
import { format } from "date-fns";

export default function MessagesCard() {
  const { data: messages, isLoading } = useRecentMessages();
  
  // Function to format time ago
  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return "just now";
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    
    const diffInHours = Math.floor(diffInMinutes / 60);
    if (diffInHours < 24) return `${diffInHours}h ago`;
    
    return format(date, "MMM d");
  };
  
  // Get today's message count
  const todayCount = messages?.filter(msg => {
    const msgDate = new Date(msg.createdAt);
    const today = new Date();
    return (
      msgDate.getDate() === today.getDate() &&
      msgDate.getMonth() === today.getMonth() &&
      msgDate.getFullYear() === today.getFullYear()
    );
  }).length || 0;
  
  return (
    <div className="bg-discord-dark rounded-lg p-5 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">Recent Messages</h3>
        <span className="px-2 py-1 rounded-full text-xs font-medium bg-discord-blue text-white">
          {todayCount} today
        </span>
      </div>
      
      {isLoading ? (
        <div className="space-y-4">
          <div className="h-16 bg-discord-bg rounded-md animate-pulse"></div>
          <div className="h-16 bg-discord-bg rounded-md animate-pulse"></div>
          <div className="h-16 bg-discord-bg rounded-md animate-pulse"></div>
        </div>
      ) : messages && messages.length > 0 ? (
        <div className="space-y-4">
          {messages.slice(0, 3).map((message, index) => (
            <div 
              key={message.id} 
              className={`border-l-2 ${message.isBot ? 'border-discord-green' : 'border-discord-blue'} pl-3 py-1`}
            >
              <div className="flex items-center mb-1">
                <span className="text-sm font-medium">{message.username}</span>
                <span className="mx-2 text-xs text-discord-light">•</span>
                <span className="text-xs text-discord-light">
                  {formatTimeAgo(new Date(message.createdAt))}
                </span>
              </div>
              <p className="text-sm">{message.content}</p>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-6 text-discord-light">
          No recent messages to display
        </div>
      )}
      
      <div className="mt-5">
        <a href="#logs" className="block w-full text-center py-2 text-discord-blue hover:underline">
          View All Activity →
        </a>
      </div>
    </div>
  );
}

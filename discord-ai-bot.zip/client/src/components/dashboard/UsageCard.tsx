import { useBotStats } from "@/hooks/use-bot-stats";

export default function UsageCard() {
  const { data: stats, isLoading } = useBotStats();
  
  // API call limits
  const API_CALL_LIMIT = 3000;
  const TOKEN_LIMIT = 500000;
  
  // Calculate percentages
  const apiCallPercentage = Math.min(100, Math.round(((stats?.apiCalls || 0) / API_CALL_LIMIT) * 100));
  const tokenPercentage = Math.min(100, Math.round(((stats?.tokensUsed || 0) / TOKEN_LIMIT) * 100));
  
  // Format token number with K suffix
  const formatTokenNumber = (num: number) => {
    if (num >= 1000) {
      return `${Math.round(num / 1000)}K`;
    }
    return num.toString();
  };
  
  return (
    <div className="bg-discord-dark rounded-lg p-5 shadow-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium">AI Usage Stats</h3>
        <span className="text-xs text-discord-light">This Month</span>
      </div>
      
      <div className="space-y-4">
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-discord-light">API Calls</span>
            <span>
              {isLoading ? "Loading..." : `${stats?.apiCalls?.toLocaleString() || 0} / ${API_CALL_LIMIT.toLocaleString()}`}
            </span>
          </div>
          <div className="w-full bg-discord-bg rounded-full h-2.5">
            <div 
              className="bg-discord-blue h-2.5 rounded-full" 
              style={{ width: `${apiCallPercentage}%` }}
            ></div>
          </div>
        </div>
        
        <div>
          <div className="flex justify-between mb-1">
            <span className="text-discord-light">Tokens Used</span>
            <span>
              {isLoading ? "Loading..." : 
                `${formatTokenNumber(stats?.tokensUsed || 0)} / ${formatTokenNumber(TOKEN_LIMIT)}`}
            </span>
          </div>
          <div className="w-full bg-discord-bg rounded-full h-2.5">
            <div 
              className="bg-discord-blue h-2.5 rounded-full" 
              style={{ width: `${tokenPercentage}%` }}
            ></div>
          </div>
        </div>
        
        <div className="bg-discord-bg rounded-md p-3 text-sm">
          <div className="flex items-center mb-2">
            <span className="material-icons text-discord-green mr-2 text-sm">info</span>
            <span className="font-medium">Current Plan: Standard</span>
          </div>
          <p className="text-discord-light">
            Your API usage is within limits. Resets on {new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).toLocaleDateString()}.
          </p>
        </div>
      </div>
      
      <div className="mt-5">
        <button className="w-full py-2 bg-discord-blue text-white rounded-md hover:bg-opacity-90 transition-colors">
          <span className="flex items-center justify-center">
            <span className="material-icons mr-2 text-sm">upgrade</span>
            Upgrade Plan
          </span>
        </button>
      </div>
    </div>
  );
}

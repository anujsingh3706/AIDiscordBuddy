import StatusCard from "./StatusCard";
import MessagesCard from "./MessagesCard";
import UsageCard from "./UsageCard";
import ConfigSection from "./ConfigSection";
import CommandsTable from "./CommandsTable";

export default function Dashboard() {
  return (
    <div id="dashboard-section" className="p-6">
      <div className="mb-6">
        <h2 className="text-2xl font-semibold mb-1">Dashboard</h2>
        <p className="text-discord-light">Monitor and manage your AI Discord bot</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatusCard />
        <MessagesCard />
        <UsageCard />
      </div>

      <ConfigSection />
      
      <CommandsTable />
    </div>
  );
}
